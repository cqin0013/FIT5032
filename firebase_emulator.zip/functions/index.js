// functions/index.js
const { onRequest } = require("firebase-functions/v2/https");
const admin = require("firebase-admin");
const cors = require("cors")({ origin: true });

admin.initializeApp();

exports.countBooks = onRequest((req, res) => {
  // 允许跨域
  cors(req, res, async () => {
    try {
      // 只允许 GET（如需支持更多方法可自行放开）
      if (req.method !== "GET") {
        return res.status(405).send("Method Not Allowed");
      }

      // 基于关键字 "books" 读取集合
      const booksCollection = admin.firestore().collection("books");
      const snapshot = await booksCollection.get();
      const count = snapshot.size;

      // 成功返回
      return res.status(200).send({ count });
    } catch (error) {
      // try/catch 处理异常
      console.error("Error counting books:", error.message);
      return res.status(500).send("Error counting books");
    }
  });
});
