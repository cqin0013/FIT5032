<template>
  <main style="max-width:680px;margin:2rem auto;">
    <h2>Admin console</h2>
    <p>Only the admin role can access this page.</p>

  </main>
</template>
